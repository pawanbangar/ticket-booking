export const TICKET_COST=200;
export const BOOKING_CHARGE=20;
export const PAYMENT_TIME=5; //seconds
export const MOVIE_DETAILS_PREFIX="/details/"
export const CUSTOMIZE_ROW_PREFIX="/customize/"
export const BOOK_TICKETS_PREFIX="/seats/"