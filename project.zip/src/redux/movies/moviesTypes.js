const moviesActionTypes = {
  FETCH_MOVIES: "FETCH_MOVIES",
};

export default moviesActionTypes;
